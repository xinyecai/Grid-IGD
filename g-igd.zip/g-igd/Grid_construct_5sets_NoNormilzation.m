%% ���ɸ���ϵͳ�Լ����ݵ�һЩ�淶������
function [ FilterNonSolutions1,FilterNonSolutions2,FilterNonSolutions3,FilterNonSolutions4,FilterNonSolutions5,nonpopObj,idealPoint,nadirPoint ] = Grid_construct_5sets_NoNormilzation( solutions1 , solutions2 ,solutions3,solutions4,solutions5)

    [~, noOfObjs1] = size(solutions1);
    [~, noOfObjs2] = size(solutions2);
    [~, noOfObjs3] = size(solutions3);
    [~, noOfObjs4] = size(solutions4);
    [~, noOfObjs5] = size(solutions5);
    popAll=[solutions1;solutions2;solutions3;solutions4;solutions5];
        nonSolutions1=solutions1';
        nonSolutions2=solutions2';
        nonSolutions3=solutions3';
        nonSolutions4=solutions4';
        nonSolutions5=solutions5';
    nonpopObj=elite_nondominated(popAll');  
    idealPoint = min(nonpopObj,[],2);
    nadirPoint = max(nonpopObj,[],2);
    more1=zeros(noOfObjs1,size(nonSolutions1,2));
    more2=zeros(noOfObjs2,size(nonSolutions2,2));
    more3=zeros(noOfObjs3,size(nonSolutions3,2));
    more4=zeros(noOfObjs4,size(nonSolutions4,2));
    more5=zeros(noOfObjs5,size(nonSolutions5,2));
    for o=1:noOfObjs1
        more1(o,:)=nonSolutions1(o,:)>nadirPoint(o,:) | nonSolutions1(o,:)<idealPoint(o,:);
        more2(o,:)=nonSolutions2(o,:)>nadirPoint(o,:) | nonSolutions2(o,:)<idealPoint(o,:);
        more3(o,:)=nonSolutions3(o,:)>nadirPoint(o,:) | nonSolutions3(o,:)<idealPoint(o,:);
        more4(o,:)=nonSolutions4(o,:)>nadirPoint(o,:) | nonSolutions4(o,:)<idealPoint(o,:);
        more5(o,:)=nonSolutions5(o,:)>nadirPoint(o,:) | nonSolutions5(o,:)<idealPoint(o,:);
    end
    tmp1 = sum(more1)==0;
    tmp2 = sum(more2)==0;
    tmp3 = sum(more3)==0;
    tmp4 = sum(more4)==0;
    tmp5 = sum(more5)==0;
    elite1= tmp1==1;
    elite2= tmp2==1;
    elite3= tmp3==1;
    elite4= tmp4==1;
    elite5= tmp5==1;
    FilterNonSolutions1=nonSolutions1;
    FilterNonSolutions2=nonSolutions2;
    FilterNonSolutions3=nonSolutions3;
    FilterNonSolutions4=nonSolutions4;
    FilterNonSolutions5=nonSolutions5;
