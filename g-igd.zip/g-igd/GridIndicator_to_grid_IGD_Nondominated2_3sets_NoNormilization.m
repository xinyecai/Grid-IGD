function [GIs1,GIs2,GIs3,flag]=GridIndicator_to_grid_IGD_Nondominated2_3sets_NoNormilization(normSolutions1,normSolutions2,normSolutions3,normAllPop,K,idealPoint,nadirPoint)
%%%�����µ�Reference Points������⼯ȡ��֧���(nondominated)
%%%ȡ�õ�Reference Points��ȡ��֧���
%%%����IGD���Ҳο���ֻ��Ӧ�������ڸ����еĽ⼰������T�ڵĽ�����Ƕ�Ӧ�����н⡣
    flag=false;
    idealmax=nadirPoint-idealPoint;
    delta=idealmax/K;  
    
     k=delta./nadirPoint;
    nadirPoint=nadirPoint.*(1+k);
    idealmax=nadirPoint-idealPoint;
    delta=idealmax/K;  
    
    coor1=zeros(size(normSolutions1,1),size(normSolutions1,2));
    coor2=zeros(size(normSolutions2,1),size(normSolutions2,2));
    coor3=zeros(size(normSolutions3,1),size(normSolutions3,2));
    for i=1:size(normSolutions1,2)
        coor1(:,i)=ceil((normSolutions1(:,i)-idealPoint)./delta);
    end
    for i=1:size(normSolutions2,2)
        coor2(:,i)=ceil((normSolutions2(:,i)-idealPoint)./delta);
    end
    for i=1:size(normSolutions3,2)
        coor3(:,i)=ceil((normSolutions3(:,i)-idealPoint)./delta);
    end
    coor1(coor1==0)=1; 
    coor2(coor2==0)=1;
    coor3(coor3==0)=1;
    coorAllNonPop_non=zeros(size(normAllPop,1),size(normAllPop,2));
    for i=1:size(normAllPop,2)
        coorAllNonPop_non(:,i)=ceil((normAllPop(:,i)-idealPoint)./delta);      
    end
    coorAllNonPop_non(coorAllNonPop_non==0)=1; 
    
    newcoorAllNonPop=unique(coorAllNonPop_non','rows');  
    coorAllNonPop=newcoorAllNonPop';
    ReferPoints_LeftBottom=zeros(size(coorAllNonPop,1),size(coorAllNonPop,2));
    for i=1:size(coorAllNonPop,2)
        ReferPoints_LeftBottom(:,i)=(coorAllNonPop(:,i)-1).*delta+idealPoint;
    end
        
    Add_ReferPoints=[];
    ReferPoints=[ReferPoints_LeftBottom Add_ReferPoints];
 [sortcoor_non,index_non]=sortrows( coorAllNonPop_non');
 [classfiedIndex_non,num_non] = classfied( sortcoor_non,index_non); 
  needIndex_non=zeros(1,num_non);
  for i=1:num_non
        needIndex_non(i)=classfiedIndex_non{i,1}(:,1);    
  end
coorAllNonPop=coorAllNonPop_non(:,needIndex_non);
    ReferPoints_LeftBottom=zeros(size(coorAllNonPop,1),size(coorAllNonPop,2));
    for i=1:size(coorAllNonPop,2)     
        ReferPoints_LeftBottom(:,i)=(coorAllNonPop(:,i)-1).*delta+idealPoint;
    end
    Add_ReferPoints=[];
    ReferPoints=[ReferPoints_LeftBottom Add_ReferPoints];
    newRef=[];
    for i=1:num_non
        neighborIndex_non=[classfiedIndex_non{i,1}];
        if length(neighborIndex_non)==1
            newRef=[newRef normAllPop(:,neighborIndex_non)];
        else
            minDis=sqrt(sum((normAllPop(:,neighborIndex_non)-repmat(ReferPoints(:,i),1,length(neighborIndex_non))).^2));
            [C,I]=min(minDis);
            index=find(minDis==C);
            newRef=[newRef normAllPop(:,neighborIndex_non(:,index))];
        end
    end
    [sortcoor1,index1]=sortrows(coor1'); 
    [sortcoor2,index2]=sortrows(coor2');
    [sortcoor3,index3]=sortrows(coor3');
    [classfiedIndex1,num1] = classfied( sortcoor1,index1);    
    [classfiedIndex2,num2] = classfied( sortcoor2,index2);
    [classfiedIndex3,num3] = classfied( sortcoor3,index3);    
    needIndex1=zeros(1,num1);
    needIndex2=zeros(1,num2);
    needIndex3=zeros(1,num3);
    for i=1:num1
        needIndex1(i)=classfiedIndex1{i,1}(:,1);    
    end
    needcoor1=coor1(:,needIndex1);    
    
    for i=1:num2
        needIndex2(i)=classfiedIndex2{i,1}(:,1);
    end
    needcoor2=coor2(:,needIndex2);   
    
    for i=1:num3
        needIndex3(i)=classfiedIndex3{i,1}(:,1);
    end
    needcoor3=coor3(:,needIndex3);
    

    NeighborIndex=cell(size(ReferPoints,2),3);   
    for i=1:size(coorAllNonPop,2)
        needcoorAllNonPop1=repmat(coorAllNonPop(:,i),1,num1);
        needcoorAllNonPop2=repmat(coorAllNonPop(:,i),1,num2);
        needcoorAllNonPop3=repmat(coorAllNonPop(:,i),1,num3);
        neigh1=sum(abs(needcoor1-needcoorAllNonPop1));   
        neigh2=sum(abs(needcoor2-needcoorAllNonPop2));
        neigh3=sum(abs(needcoor3-needcoorAllNonPop3));
        [~,n1]=find(neigh1<size(normAllPop,1)*K);
        [~,n2]=find(neigh2<size(normAllPop,1)*K);
        [~,n3]=find(neigh3<size(normAllPop,1)*K);
        
        neighborIndex1=[classfiedIndex1{n1,1}];
        neighborIndex2=[classfiedIndex2{n2,1}];
        neighborIndex3=[classfiedIndex3{n3,1}];
        NeighborIndex{i,1}=neighborIndex1;
        NeighborIndex{i,2}=neighborIndex2;
        NeighborIndex{i,3}=neighborIndex3;
    end
    idealPoint=zeros(1,size(normSolutions1,1));
    nadirPoint=ones(1,size(normSolutions1,1));
    Distance_Ref_To_Solu=zeros(3,size(ReferPoints,2));   
    for i=1:size(ReferPoints,2)
        SolutionIndex1=NeighborIndex{i,1};
        SolutionIndex2=NeighborIndex{i,2};
        SolutionIndex3=NeighborIndex{i,3};
        if isempty(SolutionIndex1) 
            Distance_Ref_To_Solu(1,i)=sqrt(sum((nadirPoint-idealPoint).^2)); 
        else
            prepare_no_empty= (normSolutions1(:,SolutionIndex1)-repmat(ReferPoints(:,i),1,size(SolutionIndex1,2)));
            Distance_Ref_To_Solu(1,i)=min((sqrt(sum(prepare_no_empty.^2))),[],2);
        end  
        if isempty(SolutionIndex2) 
            Distance_Ref_To_Solu(2,i)=sqrt(sum((nadirPoint-idealPoint).^2));
        else
            prepare_no_empty= (normSolutions2(:,SolutionIndex2)-repmat(ReferPoints(:,i),1,size(SolutionIndex2,2)));
            Distance_Ref_To_Solu(2,i)=min((sqrt(sum(prepare_no_empty.^2))),[],2);
        end
        if isempty(SolutionIndex3) 
            Distance_Ref_To_Solu(3,i)=sqrt(sum((nadirPoint-idealPoint).^2)); 
        else
            prepare_no_empty= (normSolutions3(:,SolutionIndex3)-repmat(ReferPoints(:,i),1,size(SolutionIndex3,2)));
            Distance_Ref_To_Solu(3,i)=min((sqrt(sum(prepare_no_empty.^2))),[],2);
        end     
    end
    GIs1=sum(Distance_Ref_To_Solu(1,:),2)/size(ReferPoints,2);
    GIs2=sum(Distance_Ref_To_Solu(2,:),2)/size(ReferPoints,2);
    GIs3=sum(Distance_Ref_To_Solu(3,:),2)/size(ReferPoints,2);
end