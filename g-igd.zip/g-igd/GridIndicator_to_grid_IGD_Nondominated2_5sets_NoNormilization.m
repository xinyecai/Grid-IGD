function [GIs1,GIs2,GIs3,GIs4,GIs5,ReferPoints,flag]=GridIndicator_to_grid_IGD_Nondominated2_5sets_NoNormilization(normSolutions1,normSolutions2,normSolutions3,normSolutions4,normSolutions5,normAllPop,K,idealPoint,nadirPoint)
%%%�����µ�Reference Points������⼯ȡ��֧���(nondominated)
%%%ȡ�õ�Reference Points��ȡ��֧���
%%%����IGD���Ҳο���ֻ��Ӧ�������ڸ����еĽ⼰������T�ڵĽ�����Ƕ�Ӧ�����н⡣
    flag=false;
    idealmax=nadirPoint-idealPoint;
    delta=idealmax/K;  
     k=delta./nadirPoint;
    nadirPoint=nadirPoint.*(1+k);
    idealmax=nadirPoint-idealPoint;
    delta=idealmax/K;  
    coor1=zeros(size(normSolutions1,1),size(normSolutions1,2));
    coor2=zeros(size(normSolutions2,1),size(normSolutions2,2));
    coor3=zeros(size(normSolutions3,1),size(normSolutions3,2));
    coor4=zeros(size(normSolutions4,1),size(normSolutions4,2));
    coor5=zeros(size(normSolutions5,1),size(normSolutions5,2));
    for i=1:size(normSolutions1,2)
        coor1(:,i)=ceil((normSolutions1(:,i)-idealPoint)./delta);
    end
    for i=1:size(normSolutions2,2)
        coor2(:,i)=ceil((normSolutions2(:,i)-idealPoint)./delta);
    end
    for i=1:size(normSolutions3,2)
        coor3(:,i)=ceil((normSolutions3(:,i)-idealPoint)./delta);
    end
    for i=1:size(normSolutions4,2)
        coor4(:,i)=ceil((normSolutions4(:,i)-idealPoint)./delta);
    end
    for i=1:size(normSolutions5,2)
        coor5(:,i)=ceil((normSolutions5(:,i)-idealPoint)./delta);
    end
    coor1(coor1==0)=1; 
    coor2(coor2==0)=1;
    coor3(coor3==0)=1;
    coor4(coor4==0)=1;
    coor5(coor5==0)=1;
    coorAllNonPop_non=zeros(size(normAllPop,1),size(normAllPop,2));
    for i=1:size(normAllPop,2)
        coorAllNonPop_non(:,i)=ceil((normAllPop(:,i)-idealPoint)./delta);      
    end
    coorAllNonPop_non(coorAllNonPop_non==0)=1;
    
    newcoorAllNonPop=unique(coorAllNonPop_non','rows'); 
    coorAllNonPop=newcoorAllNonPop';
    ReferPoints_LeftBottom=zeros(size(coorAllNonPop,1),size(coorAllNonPop,2));
    for i=1:size(coorAllNonPop,2)
        ReferPoints_LeftBottom(:,i)=(coorAllNonPop(:,i)-1).*delta+idealPoint;
    end
        
    Add_ReferPoints=[];

    ReferPoints=[ReferPoints_LeftBottom Add_ReferPoints];
    %% ���Ͳο�������ͬһ������
    [sortcoor1,index1]=sortrows(coor1');  
    [sortcoor2,index2]=sortrows(coor2');
    [sortcoor3,index3]=sortrows(coor3');
    [sortcoor4,index4]=sortrows(coor4');
    [sortcoor5,index5]=sortrows(coor5');
    [classfiedIndex1,num1] = classfied( sortcoor1,index1);    
    [classfiedIndex2,num2] = classfied( sortcoor2,index2);
    [classfiedIndex3,num3] = classfied( sortcoor3,index3);
    [classfiedIndex4,num4] = classfied( sortcoor4,index4);
    [classfiedIndex5,num5] = classfied( sortcoor5,index5);     
    needIndex1=zeros(1,num1);
    needIndex2=zeros(1,num2);
    needIndex3=zeros(1,num3);
    needIndex4=zeros(1,num4);
    needIndex5=zeros(1,num5);
    for i=1:num1
        needIndex1(i)=classfiedIndex1{i,1}(:,1);    
    end
    needcoor1=coor1(:,needIndex1);   
    
    for i=1:num2
        needIndex2(i)=classfiedIndex2{i,1}(:,1);
    end
    needcoor2=coor2(:,needIndex2);  
    
    for i=1:num3
        needIndex3(i)=classfiedIndex3{i,1}(:,1);
    end
    needcoor3=coor3(:,needIndex3);
    
    for i=1:num4
        needIndex4(i)=classfiedIndex4{i,1}(:,1);
    end
    needcoor4=coor4(:,needIndex4);
    
    for i=1:num5
        needIndex5(i)=classfiedIndex5{i,1}(:,1);
    end
    needcoor5=coor5(:,needIndex5);

    NeighborIndex=cell(size(ReferPoints,2),5);   
    for i=1:size(coorAllNonPop,2)
        needcoorAllNonPop1=repmat(coorAllNonPop(:,i),1,num1);
        needcoorAllNonPop2=repmat(coorAllNonPop(:,i),1,num2);
        needcoorAllNonPop3=repmat(coorAllNonPop(:,i),1,num3);
        needcoorAllNonPop4=repmat(coorAllNonPop(:,i),1,num4);
        needcoorAllNonPop5=repmat(coorAllNonPop(:,i),1,num5);
        neigh1=sum(abs(needcoor1-needcoorAllNonPop1));  
        neigh2=sum(abs(needcoor2-needcoorAllNonPop2));
        neigh3=sum(abs(needcoor3-needcoorAllNonPop3));
        neigh4=sum(abs(needcoor4-needcoorAllNonPop4));
        neigh5=sum(abs(needcoor5-needcoorAllNonPop5));
        [~,n1]=find(neigh1<size(normSolutions1,1)*K);
        [~,n2]=find(neigh2<size(normSolutions1,1)*K);
        [~,n3]=find(neigh3<size(normSolutions1,1)*K);
        [~,n4]=find(neigh4<size(normSolutions1,1)*K);
        [~,n5]=find(neigh5<size(normSolutions1,1)*K);
        neighborIndex1=[classfiedIndex1{n1,1}];
        neighborIndex2=[classfiedIndex2{n2,1}];
        neighborIndex3=[classfiedIndex3{n3,1}];
        neighborIndex4=[classfiedIndex4{n4,1}];
        neighborIndex5=[classfiedIndex5{n5,1}];
        NeighborIndex{i,1}=neighborIndex1;
        NeighborIndex{i,2}=neighborIndex2;
        NeighborIndex{i,3}=neighborIndex3;
        NeighborIndex{i,4}=neighborIndex4;
        NeighborIndex{i,5}=neighborIndex5;
    end
   
    
    idealPoint=zeros(1,size(normSolutions1,1));
    nadirPoint=ones(1,size(normSolutions1,1));
    Distance_Ref_To_Solu=zeros(5,size(ReferPoints,2));   
    
    Distance_Prepare=zeros(5,size(ReferPoints,2));  
    

    
    for i=1:size(ReferPoints,2)
        SolutionIndex1=NeighborIndex{i,1};
        SolutionIndex2=NeighborIndex{i,2};
        SolutionIndex3=NeighborIndex{i,3};
        SolutionIndex4=NeighborIndex{i,4};
        SolutionIndex5=NeighborIndex{i,5};
        if isempty(SolutionIndex1)  
          Distance_Ref_To_Solu(1,i)=sqrt(sum((nadirPoint-idealPoint).^2)); 
        else
            prepare_no_empty= (repmat(ReferPoints(:,i),1,size(SolutionIndex1,2))-normSolutions1(:,SolutionIndex1));
            prepare_no_empty1= prepare_no_empty<0;
            final_prepare_no_empty= prepare_no_empty.*prepare_no_empty1;
            Distance_Ref_To_Solu(1,i)=min((sqrt(sum(final_prepare_no_empty.^2))),[],2);
        end  
        if isempty(SolutionIndex2) 
            Distance_Ref_To_Solu(2,i)=sqrt(sum((nadirPoint-idealPoint).^2));  
        else
            prepare_no_empty= (repmat(ReferPoints(:,i),1,size(SolutionIndex2,2))-normSolutions2(:,SolutionIndex2));
            prepare_no_empty1= prepare_no_empty<0;
            final_prepare_no_empty= prepare_no_empty.*prepare_no_empty1;
            Distance_Ref_To_Solu(2,i)=min((sqrt(sum(final_prepare_no_empty.^2))),[],2);
        end
        
        if isempty(SolutionIndex3) 
            Distance_Ref_To_Solu(3,i)=sqrt(sum((nadirPoint-idealPoint).^2)); 
        else
            prepare_no_empty= (repmat(ReferPoints(:,i),1,size(SolutionIndex3,2))-normSolutions3(:,SolutionIndex3));
            prepare_no_empty1= prepare_no_empty<0;
            final_prepare_no_empty= prepare_no_empty.*prepare_no_empty1;
            Distance_Ref_To_Solu(3,i)=min((sqrt(sum(final_prepare_no_empty.^2))),[],2);
        end
        
        if isempty(SolutionIndex4) 
            Distance_Ref_To_Solu(4,i)=sqrt(sum((nadirPoint-idealPoint).^2));  
        else
            prepare_no_empty= (repmat(ReferPoints(:,i),1,size(SolutionIndex4,2))-normSolutions4(:,SolutionIndex4));
            prepare_no_empty1= prepare_no_empty<0;
            final_prepare_no_empty= prepare_no_empty.*prepare_no_empty1;     
            Distance_Ref_To_Solu(4,i)=min((sqrt(sum(final_prepare_no_empty.^2))),[],2);
        end
        
        if isempty(SolutionIndex5) 
            Distance_Ref_To_Solu(5,i)=sqrt(sum((nadirPoint-idealPoint).^2));  
        else
            prepare_no_empty= (repmat(ReferPoints(:,i),1,size(SolutionIndex5,2))-normSolutions5(:,SolutionIndex5));
             prepare_no_empty1= prepare_no_empty<0;
            final_prepare_no_empty= prepare_no_empty.*prepare_no_empty1;
            Distance_Ref_To_Solu(5,i)=min((sqrt(sum(final_prepare_no_empty.^2))),[],2);
        end
    end
    GIs1=sum(Distance_Ref_To_Solu(1,:),2)/size(ReferPoints,2);
    GIs2=sum(Distance_Ref_To_Solu(2,:),2)/size(ReferPoints,2);
    GIs3=sum(Distance_Ref_To_Solu(3,:),2)/size(ReferPoints,2);
    GIs4=sum(Distance_Ref_To_Solu(4,:),2)/size(ReferPoints,2);
    GIs5=sum(Distance_Ref_To_Solu(5,:),2)/size(ReferPoints,2);    
end