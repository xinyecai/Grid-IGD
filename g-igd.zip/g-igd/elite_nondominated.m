function non = elite_nondominated(ObjVals)

[nmbOfObjs,nmbOfIndivs] = size( ObjVals);
sortedPop=(sortrows(ObjVals'))';

elite=[];
% for i=1:nmbOfIndivs
%     if isempty(elite)
%         elite=[elite i];
%     else
%         hh=0;
%         for j=length(elite):-1:1            
%             less_eq=zeros(nmbOfObjs,1);
%             less=zeros(nmbOfObjs,1);
%             for o=1:nmbOfObjs
%                 tmp1=sortedPop(o,elite(j))<=sortedPop(o,i);
%                 tmp2=sortedPop(o,elite(j))<sortedPop(o,i);
%                 less_eq(o,:)=tmp1;
%                 less(o,:)=tmp2;
%             end
%             tmp=(sum(less_eq)==nmbOfObjs)&(sum(less)>0);
%             if sum(tmp)==0;
%                 hh=hh+1;
%             else
%                 break;
%             end
%         end
%         if hh==length(elite)
%             elite=[elite i];
%         end
%     end
% end

for i=1:nmbOfIndivs
    if isempty(elite)
        elite=[elite i];
    else
        less_eq=zeros(nmbOfObjs,length(elite));
        less=zeros(nmbOfObjs,length(elite));
        elitePop=sortedPop(:,elite);
        projbs=repmat(sortedPop(:,i),1,length(elite));
        for o=1:nmbOfObjs
            tmp1=elitePop(o,:)<=projbs(o,:);
            tmp2=elitePop(o,:)<projbs(o,:);
            less_eq(o,:)=tmp1;
            less(o,:)=tmp2;
        end
        tmp=(sum(less_eq)==nmbOfObjs)&(sum(less)>0);
        if sum(tmp)==0
            elite=[elite i];
        end
    end
end

non = sortedPop(:,elite); %���з�֧���
