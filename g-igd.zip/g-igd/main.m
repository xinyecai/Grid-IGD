clear;clc;

%% ----����⼯dtlz 2
A = importdata('C:\Users\ALIENWARE\Desktop\g-igd\Grid-IGD�Ա�ʵ������\MOEAD-DTLZ2-3D');
B = importdata('C:\Users\ALIENWARE\Desktop\g-igd\Grid-IGD�Ա�ʵ������\IBEA-DTLZ2-3D');
C = importdata('C:\Users\ALIENWARE\Desktop\g-igd\Grid-IGD�Ա�ʵ������\PAES-DTLZ2-3D');
D = importdata('C:\Users\ALIENWARE\Desktop\g-igd\Grid-IGD�Ա�ʵ������\GrEA-DTLZ2-3D');
E = importdata('C:\Users\ALIENWARE\Desktop\g-igd\Grid-IGD�Ա�ʵ������\NSGAIII-DTLZ2-3D');
%% ----����⼯dtlz 7
% A = importdata('C:\Users\ALIENWARE\Desktop\g-igd\Grid-IGD�Ա�ʵ������\MOEAD-DTLZ7-3D');
% B = importdata('C:\Users\ALIENWARE\Desktop\g-igd\Grid-IGD�Ա�ʵ������\IBEA-DTLZ7-3D');
% C = importdata('C:\Users\ALIENWARE\Desktop\g-igd\Grid-IGD�Ա�ʵ������\PAES-DTLZ7-3D');
% D = importdata('C:\Users\ALIENWARE\Desktop\g-igd\Grid-IGD�Ա�ʵ������\GrEA-DTLZ7-3D');
% E = importdata('C:\Users\ALIENWARE\Desktop\g-igd\Grid-IGD�Ա�ʵ������\NSGAIII-DTLZ7-3D');
%% UF9
% load MOEAD-UF9-3D
% A =  a;
% load IBEA-UF9-3D
% B = a;
% load PAES-UF9-3D
% C = a;
% load GrEA-UF9-3D
% D =  a;
% load NSGAIII-UF9-3D
% E =  a;
%% WFG2-3
% load MOEAD-WFG2-3D
% A = a;
% load IBEA-WFG2-3D
% B = a;
% load PAES-WFG2-3D
% C = a;
% load GrEA-WFG2-3D
% D =  a;
% load NSGAIII-WFG2-3D
% E =  a;
%% WFG2-5
% load MOEAD-WFG2-5D
% A =  a;
% load IBEA-WFG2-5D
% B = a;
% load PAES-WFG2-5D
% C = a;
% load GrEA-WFG2-5D
% D =  a;
% load NSGAIII-WFG2-5D
% E =  a;
%% WFG2-10
% load MOEAD-WFG2-10D
% A =  a;
% load IBEA-WFG2-10D
% B = a;
% load PAES-WFG2-10D
% C = a;
% load GrEA-WFG2-10D
% D =  a;
% load NSGAIII-WFG2-10D
% E =  a;

% A=load(sprintf('Size_120_uniform_[0,1].dat'));
% B=load(sprintf('Size_120_uniform_[0.1,0.8].dat'));
% C=load(sprintf('Size_120_uniform_[0.2,0.6].dat'));
% B=load(sprintf('Size_120_un-uniform [0,1]_0.5.dat'));
% C=load(sprintf('Size_120_un-uniform_[0,1].dat'));
% B=load(sprintf('Size_120_converge_0.8.dat'));
% C=load(sprintf('Size_120_converge_0.5.dat'));


%% ���ø�����K%%%
K= 18
%% ----3���
% [FilterNonSolutions1,FilterNonSolutions2,FilterNonSolutions3,nonpopObj,idealPoint,nadirPoint] = Grid_construct_3sets_NoNormilzation( A,B,C );
% [GIA,GIB,GIC,flag1]=GridIndicator_to_grid_IGD_Nondominated2_3sets_NoNormilization(FilterNonSolutions1,FilterNonSolutions2,FilterNonSolutions3,nonpopObj,K,idealPoint,nadirPoint);
%% ----5���
[FilterNonSolutions1,FilterNonSolutions2,FilterNonSolutions3,FilterNonSolutions4,FilterNonSolutions5,nonpopObj,idealPoint,nadirPoint] = Grid_construct_5sets_NoNormilzation( A,B,C,D,E );
[GIA,GIB,GIC,GID,GIE,ReferPoints,flag1]=GridIndicator_to_grid_IGD_Nondominated2_5sets_NoNormilization(FilterNonSolutions1,FilterNonSolutions2,FilterNonSolutions3,FilterNonSolutions4,FilterNonSolutions5,nonpopObj,K,idealPoint,nadirPoint);


