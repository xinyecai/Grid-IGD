function [classfiedIndex,tt] = classfied( sortcoor, index )
    classfiedIndex=cell(size(sortcoor,1),1);
    classfiedResult=cell(size(sortcoor,1),1);
    tt=1;
    classfiedIndex{tt,1}=[classfiedIndex{tt,1} index(1,:)];
    classfiedResult{tt,1}=[classfiedResult{tt,1};sortcoor(1,:)];
    for i=2:size(sortcoor,1)
        if isequal(sortcoor(i,:),sortcoor(i-1,:))~=1            
            tt=tt+1;
        end
        classfiedIndex{tt,1}=[classfiedIndex{tt,1} index(i,:)];       
        classfiedResult{tt,1}=[classfiedResult{tt,1};sortcoor(i,:)];       
    end
end

