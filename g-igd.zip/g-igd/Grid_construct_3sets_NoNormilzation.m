%% ���ɸ���ϵͳ�Լ����ݵ�һЩ�淶������
function [ FilterNonSolutions1,FilterNonSolutions2,FilterNonSolutions3,nonpopObj,idealPoint,nadirPoint ] = Grid_construct_3sets_NoNormilzation( solutions1 , solutions2 ,solutions3)
    [~, noOfObjs1] = size(solutions1);
    [~, noOfObjs2] = size(solutions2);
    [~, noOfObjs3] = size(solutions3);
    popAll=[solutions1;solutions2;solutions3];
        nonSolutions1=solutions1';
        nonSolutions2=solutions2';
        nonSolutions3=solutions3';
    nonpopObj=elite_nondominated(popAll');      
    idealPoint = min(nonpopObj,[],2);
    nadirPoint = max(nonpopObj,[],2);
    more1=zeros(noOfObjs1,size(nonSolutions1,2));
    more2=zeros(noOfObjs2,size(nonSolutions2,2));
    more3=zeros(noOfObjs3,size(nonSolutions3,2));
    for o=1:noOfObjs1
        temp1=nonSolutions1(o,:)>nadirPoint(o,:) | nonSolutions1(o,:)<idealPoint(o,:);
        temp2=nonSolutions2(o,:)>nadirPoint(o,:) | nonSolutions2(o,:)<idealPoint(o,:);
        temp3=nonSolutions3(o,:)>nadirPoint(o,:) | nonSolutions3(o,:)<idealPoint(o,:);
        more1(o,:)=temp1;
        more2(o,:)=temp2;
        more3(o,:)=temp3;
    end
    tmp1 = sum(more1)==0;
    tmp2 = sum(more2)==0;
    tmp3 = sum(more3)==0;
    elite1= tmp1==1;
    elite2= tmp2==1;
    elite3= tmp3==1;
    FilterNonSolutions1=nonSolutions1;
    FilterNonSolutions2=nonSolutions2;
    FilterNonSolutions3=nonSolutions3;
    

